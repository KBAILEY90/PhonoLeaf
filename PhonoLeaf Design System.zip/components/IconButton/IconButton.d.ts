export interface IconButtonProps {
  shape?: 'square' | 'round';
  tone?: 'default' | 'accent' | 'outline';
  size?: number;
  label?: string;
  onClick?: () => void;
  children?: React.ReactNode;
}
export declare function IconButton(props: IconButtonProps): JSX.Element;
