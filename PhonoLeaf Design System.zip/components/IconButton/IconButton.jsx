export function IconButton({shape='square',tone='default',size=40,children,onClick,label}){
  const isRound=shape==='round';
  const toneStyle=tone==='accent'
    ?{background:'var(--accent)',color:'#fff',border:'none'}
    :tone==='outline'
    ?{background:'none',color:'var(--accent)',border:'1px solid var(--line)'}
    :{background:'none',color:'var(--text)',border:'none'};
  const style=Object.assign({
    width:size+'px',height:size+'px',display:'inline-flex',alignItems:'center',justifyContent:'center',
    borderRadius:isRound?'50%':'var(--radius)',cursor:'pointer',transition:'transform 0.15s,background 0.15s',padding:0
  },toneStyle);
  return React.createElement('button',{style,onClick,'aria-label':label,onMouseDown:e=>e.currentTarget.style.transform='scale(0.92)',onMouseUp:e=>e.currentTarget.style.transform='scale(1)',onMouseLeave:e=>e.currentTarget.style.transform='scale(1)'},children);
}
