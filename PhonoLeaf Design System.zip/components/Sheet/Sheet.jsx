export function Sheet({open,onClose,title,children}){
  const backdrop={display:open?'flex':'none',position:'fixed',inset:0,background:'rgba(0,0,0,0.4)',alignItems:'flex-end',zIndex:200};
  const sheet={background:'var(--surface)',borderTop:'1px solid var(--accent)',borderRadius:0,padding:'1.2rem 1.3rem',width:'100%',maxHeight:'80vh',overflowY:'auto'};
  const handle={width:'38px',height:'3px',background:'var(--track)',borderRadius:'2px',margin:'0 auto 1rem'};
  const titleStyle={font:'1.35rem var(--font-read)',fontWeight:400,letterSpacing:'-0.01em',marginBottom:'1rem',color:'var(--text)'};
  return React.createElement('div',{style:backdrop,onClick:onClose},
    React.createElement('div',{style:sheet,onClick:e=>e.stopPropagation()},
      React.createElement('div',{style:handle}),
      title?React.createElement('div',{style:titleStyle},title):null,
      children
    )
  );
}
