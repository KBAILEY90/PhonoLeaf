export interface SheetProps {
  open: boolean;
  onClose?: () => void;
  title?: string;
  children?: React.ReactNode;
}
export declare function Sheet(props: SheetProps): JSX.Element;
