export function Chip({on=false,onClick,children}){
  const style={
    font:'0.78rem var(--font-mono)',color:on?'var(--surface)':'var(--text-dim)',
    background:on?'var(--accent)':'none',border:'1px solid '+(on?'var(--accent)':'var(--line)'),
    padding:'0.4rem 0.7rem',borderRadius:'2px',cursor:'pointer',whiteSpace:'nowrap'
  };
  return React.createElement('button',{style,onClick},children);
}
