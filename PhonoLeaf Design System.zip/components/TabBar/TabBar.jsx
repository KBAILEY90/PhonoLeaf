export function TabBar({tabs,active,onChange}){
  const barStyle={display:'flex',justifyContent:'space-between',gap:'4px',padding:'0 10px',background:'var(--surface)',borderTop:'1px solid var(--line)'};
  return React.createElement('div',{style:barStyle},tabs.map(t=>{
    const isActive=t.id===active;
    const btnStyle={
      flex:'1 1 auto',background:'none',border:'none',cursor:'pointer',
      display:'flex',flexDirection:'column',alignItems:'center',gap:'2px',
      padding:'16px 2px 15px',borderTop:'2px solid '+(isActive?'var(--accent)':'transparent'),marginTop:'-1px',minWidth:0,
      color:isActive?'var(--accent)':'var(--text)'
    };
    const labelStyle={font:'600 0.62rem var(--font-ui)',letterSpacing:'0.06em',textTransform:'uppercase',maxWidth:'100%',overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'};
    return React.createElement('button',{key:t.id,style:btnStyle,onClick:()=>onChange&&onChange(t.id)},
      React.createElement('span',{style:labelStyle},t.label));
  }));
}
