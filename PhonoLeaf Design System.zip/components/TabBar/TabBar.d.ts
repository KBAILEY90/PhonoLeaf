export interface TabBarTab { id: string; label: string; }
export interface TabBarProps {
  tabs: TabBarTab[];
  active: string;
  onChange?: (id: string) => void;
}
export declare function TabBar(props: TabBarProps): JSX.Element;
