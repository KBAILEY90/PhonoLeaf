export function BookCard({title,author,coverColor,onClick}){
  const wrap={background:'none',border:'none',borderRadius:0,overflow:'hidden',cursor:'pointer',transition:'transform 0.2s',padding:0,textAlign:'left',width:'100%'};
  const cover={width:'100%',aspectRatio:'2/3',borderRadius:'2px',boxShadow:'var(--shadow-ink)',background:coverColor||'var(--cover-fallback)',display:'flex',alignItems:'center',justifyContent:'center',color:'var(--text-dim)',fontFamily:'var(--font-read)',fontSize:'2rem'};
  const titleStyle={marginTop:'0.6rem',font:'0.85rem var(--font-ui)',fontWeight:600,color:'var(--text)',overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'};
  const authorStyle={font:'0.72rem var(--font-ui)',color:'var(--text-dim)',overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'};
  return React.createElement('button',{style:wrap,onClick,onMouseDown:e=>e.currentTarget.style.transform='scale(0.96)',onMouseUp:e=>e.currentTarget.style.transform='scale(1)',onMouseLeave:e=>e.currentTarget.style.transform='scale(1)'},
    React.createElement('div',{style:cover},(title||'')[0]||''),
    React.createElement('div',{style:titleStyle},title),
    author?React.createElement('div',{style:authorStyle},author):null
  );
}
