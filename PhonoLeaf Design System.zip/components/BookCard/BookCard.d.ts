export interface BookCardProps {
  title: string;
  author?: string;
  coverColor?: string;
  onClick?: () => void;
}
export declare function BookCard(props: BookCardProps): JSX.Element;
