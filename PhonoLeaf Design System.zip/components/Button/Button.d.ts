export interface ButtonProps {
  variant?: 'primary' | 'outline' | 'pill';
  size?: 'md' | 'sm';
  disabled?: boolean;
  onClick?: () => void;
  children?: React.ReactNode;
}
export declare function Button(props: ButtonProps): JSX.Element;
