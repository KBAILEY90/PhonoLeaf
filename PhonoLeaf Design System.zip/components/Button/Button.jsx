export function Button({variant='primary',size='md',disabled=false,onClick,children}){
  const pad=size==='sm'?'0.6rem 1rem':'0.85rem 1.4rem';
  const font=size==='sm'?'0.85rem':'0.95rem';
  const base={fontFamily:'var(--font-ui)',fontSize:font,fontWeight:600,cursor:disabled?'default':'pointer',border:'none',borderRadius:'var(--radius)',transition:'transform 0.15s,background 0.15s',opacity:disabled?0.5:1};
  const variants={
    primary:{background:'var(--accent)',color:'#fff',padding:pad},
    outline:{background:'none',color:'var(--text)',padding:pad,border:'1px solid var(--line)'},
    pill:{background:'none',color:'var(--accent)',padding:'0.8rem 0.2rem',fontFamily:'var(--font-read)',fontWeight:400,fontSize:'0.95rem'}
  };
  const style=Object.assign({},base,variants[variant]);
  return React.createElement('button',{style,disabled,onClick,onMouseDown:e=>{if(!disabled)e.currentTarget.style.transform='scale(0.97)'},onMouseUp:e=>{e.currentTarget.style.transform='scale(1)'},onMouseLeave:e=>{e.currentTarget.style.transform='scale(1)'}},children);
}
