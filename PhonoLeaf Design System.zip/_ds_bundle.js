/* @ds-bundle: {"format":4,"namespace":"PhonoLeafMobileAppDesign_b39376","components":[{"name":"BookCard","sourcePath":"components/BookCard/BookCard.jsx"},{"name":"Button","sourcePath":"components/Button/Button.jsx"},{"name":"Chip","sourcePath":"components/Chip/Chip.jsx"},{"name":"IconButton","sourcePath":"components/IconButton/IconButton.jsx"},{"name":"Sheet","sourcePath":"components/Sheet/Sheet.jsx"},{"name":"TabBar","sourcePath":"components/TabBar/TabBar.jsx"}],"sourceHashes":{"components/BookCard/BookCard.jsx":"bdd65cd78b69","components/Button/Button.jsx":"7b95564e7d35","components/Chip/Chip.jsx":"1b59558a89eb","components/IconButton/IconButton.jsx":"346cea5fe17d","components/Sheet/Sheet.jsx":"4dd14b4825fc","components/TabBar/TabBar.jsx":"8ced8f6ad4cf"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.PhonoLeafMobileAppDesign_b39376 = window.PhonoLeafMobileAppDesign_b39376 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/BookCard/BookCard.jsx
try { (() => {
function BookCard({
  title,
  author,
  coverColor,
  onClick
}) {
  const wrap = {
    background: 'none',
    border: 'none',
    borderRadius: 0,
    overflow: 'hidden',
    cursor: 'pointer',
    transition: 'transform 0.2s',
    padding: 0,
    textAlign: 'left',
    width: '100%'
  };
  const cover = {
    width: '100%',
    aspectRatio: '2/3',
    borderRadius: '2px',
    boxShadow: 'var(--shadow-ink)',
    background: coverColor || 'var(--cover-fallback)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    color: 'var(--text-dim)',
    fontFamily: 'var(--font-read)',
    fontSize: '2rem'
  };
  const titleStyle = {
    marginTop: '0.6rem',
    font: '0.85rem var(--font-ui)',
    fontWeight: 600,
    color: 'var(--text)',
    overflow: 'hidden',
    textOverflow: 'ellipsis',
    whiteSpace: 'nowrap'
  };
  const authorStyle = {
    font: '0.72rem var(--font-ui)',
    color: 'var(--text-dim)',
    overflow: 'hidden',
    textOverflow: 'ellipsis',
    whiteSpace: 'nowrap'
  };
  return React.createElement('button', {
    style: wrap,
    onClick,
    onMouseDown: e => e.currentTarget.style.transform = 'scale(0.96)',
    onMouseUp: e => e.currentTarget.style.transform = 'scale(1)',
    onMouseLeave: e => e.currentTarget.style.transform = 'scale(1)'
  }, React.createElement('div', {
    style: cover
  }, (title || '')[0] || ''), React.createElement('div', {
    style: titleStyle
  }, title), author ? React.createElement('div', {
    style: authorStyle
  }, author) : null);
}
Object.assign(__ds_scope, { BookCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/BookCard/BookCard.jsx", error: String((e && e.message) || e) }); }

// components/Button/Button.jsx
try { (() => {
function Button({
  variant = 'primary',
  size = 'md',
  disabled = false,
  onClick,
  children
}) {
  const pad = size === 'sm' ? '0.6rem 1rem' : '0.85rem 1.4rem';
  const font = size === 'sm' ? '0.85rem' : '0.95rem';
  const base = {
    fontFamily: 'var(--font-ui)',
    fontSize: font,
    fontWeight: 600,
    cursor: disabled ? 'default' : 'pointer',
    border: 'none',
    borderRadius: 'var(--radius)',
    transition: 'transform 0.15s,background 0.15s',
    opacity: disabled ? 0.5 : 1
  };
  const variants = {
    primary: {
      background: 'var(--accent)',
      color: '#fff',
      padding: pad
    },
    outline: {
      background: 'none',
      color: 'var(--text)',
      padding: pad,
      border: '1px solid var(--line)'
    },
    pill: {
      background: 'none',
      color: 'var(--accent)',
      padding: '0.8rem 0.2rem',
      fontFamily: 'var(--font-read)',
      fontWeight: 400,
      fontSize: '0.95rem'
    }
  };
  const style = Object.assign({}, base, variants[variant]);
  return React.createElement('button', {
    style,
    disabled,
    onClick,
    onMouseDown: e => {
      if (!disabled) e.currentTarget.style.transform = 'scale(0.97)';
    },
    onMouseUp: e => {
      e.currentTarget.style.transform = 'scale(1)';
    },
    onMouseLeave: e => {
      e.currentTarget.style.transform = 'scale(1)';
    }
  }, children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/Button/Button.jsx", error: String((e && e.message) || e) }); }

// components/Chip/Chip.jsx
try { (() => {
function Chip({
  on = false,
  onClick,
  children
}) {
  const style = {
    font: '0.78rem var(--font-mono)',
    color: on ? 'var(--surface)' : 'var(--text-dim)',
    background: on ? 'var(--accent)' : 'none',
    border: '1px solid ' + (on ? 'var(--accent)' : 'var(--line)'),
    padding: '0.4rem 0.7rem',
    borderRadius: '2px',
    cursor: 'pointer',
    whiteSpace: 'nowrap'
  };
  return React.createElement('button', {
    style,
    onClick
  }, children);
}
Object.assign(__ds_scope, { Chip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/Chip/Chip.jsx", error: String((e && e.message) || e) }); }

// components/IconButton/IconButton.jsx
try { (() => {
function IconButton({
  shape = 'square',
  tone = 'default',
  size = 40,
  children,
  onClick,
  label
}) {
  const isRound = shape === 'round';
  const toneStyle = tone === 'accent' ? {
    background: 'var(--accent)',
    color: '#fff',
    border: 'none'
  } : tone === 'outline' ? {
    background: 'none',
    color: 'var(--accent)',
    border: '1px solid var(--line)'
  } : {
    background: 'none',
    color: 'var(--text)',
    border: 'none'
  };
  const style = Object.assign({
    width: size + 'px',
    height: size + 'px',
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: isRound ? '50%' : 'var(--radius)',
    cursor: 'pointer',
    transition: 'transform 0.15s,background 0.15s',
    padding: 0
  }, toneStyle);
  return React.createElement('button', {
    style,
    onClick,
    'aria-label': label,
    onMouseDown: e => e.currentTarget.style.transform = 'scale(0.92)',
    onMouseUp: e => e.currentTarget.style.transform = 'scale(1)',
    onMouseLeave: e => e.currentTarget.style.transform = 'scale(1)'
  }, children);
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/IconButton/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/Sheet/Sheet.jsx
try { (() => {
function Sheet({
  open,
  onClose,
  title,
  children
}) {
  const backdrop = {
    display: open ? 'flex' : 'none',
    position: 'fixed',
    inset: 0,
    background: 'rgba(0,0,0,0.4)',
    alignItems: 'flex-end',
    zIndex: 200
  };
  const sheet = {
    background: 'var(--surface)',
    borderTop: '1px solid var(--accent)',
    borderRadius: 0,
    padding: '1.2rem 1.3rem',
    width: '100%',
    maxHeight: '80vh',
    overflowY: 'auto'
  };
  const handle = {
    width: '38px',
    height: '3px',
    background: 'var(--track)',
    borderRadius: '2px',
    margin: '0 auto 1rem'
  };
  const titleStyle = {
    font: '1.35rem var(--font-read)',
    fontWeight: 400,
    letterSpacing: '-0.01em',
    marginBottom: '1rem',
    color: 'var(--text)'
  };
  return React.createElement('div', {
    style: backdrop,
    onClick: onClose
  }, React.createElement('div', {
    style: sheet,
    onClick: e => e.stopPropagation()
  }, React.createElement('div', {
    style: handle
  }), title ? React.createElement('div', {
    style: titleStyle
  }, title) : null, children));
}
Object.assign(__ds_scope, { Sheet });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/Sheet/Sheet.jsx", error: String((e && e.message) || e) }); }

// components/TabBar/TabBar.jsx
try { (() => {
function TabBar({
  tabs,
  active,
  onChange
}) {
  const barStyle = {
    display: 'flex',
    justifyContent: 'space-between',
    gap: '4px',
    padding: '0 10px',
    background: 'var(--surface)',
    borderTop: '1px solid var(--line)'
  };
  return React.createElement('div', {
    style: barStyle
  }, tabs.map(t => {
    const isActive = t.id === active;
    const btnStyle = {
      flex: '1 1 auto',
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: '2px',
      padding: '16px 2px 15px',
      borderTop: '2px solid ' + (isActive ? 'var(--accent)' : 'transparent'),
      marginTop: '-1px',
      minWidth: 0,
      color: isActive ? 'var(--accent)' : 'var(--text)'
    };
    const labelStyle = {
      font: '600 0.62rem var(--font-ui)',
      letterSpacing: '0.06em',
      textTransform: 'uppercase',
      maxWidth: '100%',
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap'
    };
    return React.createElement('button', {
      key: t.id,
      style: btnStyle,
      onClick: () => onChange && onChange(t.id)
    }, React.createElement('span', {
      style: labelStyle
    }, t.label));
  }));
}
Object.assign(__ds_scope, { TabBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/TabBar/TabBar.jsx", error: String((e && e.message) || e) }); }

__ds_ns.BookCard = __ds_scope.BookCard;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Chip = __ds_scope.Chip;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Sheet = __ds_scope.Sheet;

__ds_ns.TabBar = __ds_scope.TabBar;

})();
