# PhonoLeaf — Green Ink Design System

Warm paper palette, sharp corners, hard offset "ink" shadows. Literata serif for display/reading type, Manrope for UI, monospace for numerals and counts.

## Tokens
`styles.css` — colors (`--bg`, `--surface`, `--accent`, `--accent2`, `--text`, `--text-dim`, `--line`), fonts, `--radius` (2px), `--shadow-ink` (hard 4px offset, no blur). Dark mode via `[data-theme="dark"]`.

## Components
- **Button** — primary (accent fill), outline, pill (text-only, serif)
- **IconButton** — square ghost or round accent/outline
- **Chip** — toggleable pill, mono numerals (sleep timer, filters)
- **TabBar** — bottom nav, words not icons, ink-rule underline for active
- **BookCard** — cover art with hard offset shadow, title/author below
- **Sheet** — bottom sheet with accent hairline top border and drag handle
